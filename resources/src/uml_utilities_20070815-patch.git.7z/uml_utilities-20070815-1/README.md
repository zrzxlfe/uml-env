This is a package script for uml_utilities and already provides the packaged packages.


can you use cmd to install:

```
sudo pacman -U uml_utilities-20070815-1-x86_64.pkg.tar.xz
```
