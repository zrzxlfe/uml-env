/* Copyright 2002 Jeff Dike
 * Licensed under the GPL
 */

#ifndef __SWITCH_H__
#define __SWITCH_H__

#define ETH_ALEN 6

#endif
